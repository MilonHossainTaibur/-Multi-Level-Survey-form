<?php 
include_once("header.php"); 
?>
<title>Multi Level Survey Form</title>
<script type="text/javascript" src="script/form.js"></script>

<style type="text/css">
  #register_form fieldset:not(:first-of-type) {
    display: none;
  }
</style>

<div class="container">
	<h2>Multi Level Survey Form</h2>		
	<div class="alert alert-success hide"></div>	
	<form id="register_form" novalidate action="multi_form_action.php" onsubmit="return validateForm()"  method="post">	
	<fieldset>
	<input type="button" class="next-form btn btn-info" value="Let's Start" />
	</fieldset>	
	<fieldset>
	 <div class="form-group">
       <label>Enter Your Name</label>
       <input type="text" name="name" id="name" required="true" class="form-control" />
      </div>
	<input type="button" name="next" class="next-form btn btn-info" value="Next" />
	</fieldset>
	
	<fieldset>
	<div class="form-group">
      <label>Enter Your Email</label>
      <input type="text" name="email" id="email" required="true" class="form-control" />
      </div>
	<input type="button" name="next"  class="next-form btn btn-info" value="Next" />
	</fieldset>

	<fieldset>
	 <div class="form-group">
      <label>Select Your Profession</label>
      <input type="text" name="profession" required="true" id="profession" class="form-control" />
      </div>
	<input type="button" name="next" class="next-form btn btn-info" value="Next" />
	</fieldset>

   <fieldset>
	<div class="form-group">
     <label>Which programming language are you using</label>
     <input type="text" name="programming_language" required="true" id="programming_language" class="form-control" />
    </div>
    <div class="form-group">
     <label>Which program tools are you using</label>
     <input type="text" name="programming_tools" required="true" id="programming_tools" class="form-control" />
    </div>
	<input type="button" name="next" class="next-form btn btn-info" value="Next" />
	</fieldset>

	<fieldset>
	 <div class="form-group">
      <label>Total years of experience</label>
      <input type="text" name="experience" required="true" id="experience" class="form-control" />
      </div>
	<input type="submit" name="submit" class="submit btn btn-success" value="Submit" />
	</fieldset>
	</form>	
</div>	

<script>
	function validateForm() {
	  let x = document.forms["register_form"]["next"].value;
	  if (x == "") {
	    alert("Name must be filled out");
	    return false;
	  }
    } 
</script>
<?php include_once("footer.php");?> 