$(document).ready(function(){  

  $(".next-form").click(function(){
    previous_form = $(this).parent();
    next_form = $(this).parent().next();
    next_form.show();
    previous_form.hide();
  });  



  $( "#register_form" ).submit(function(event) {  

  //alert();  
	var error_message = '';
	if(!$("#name").val()) {
		error_message+="Please Name";
	}
	if(!$("#email").val()) {
		error_message+="<br>Please Fill Email";
	}
	if(!$("#profession").val()) {
		error_message+="<br>Please Fill Profession";
	}
  if(!$("#programming_language").val()) {
    error_message+="<br>Please Fill Programming language";
  }
  if(!$("#programming_tools").val()) {
    error_message+="<br>Please Fill Programming tools";
  }
  if(!$("#experience").val()) {
    error_message+="<br>Please Fill Experience";
  }
	// Display error if any else submit form
	if(error_message) {
		$('.alert-success').removeClass('hide').html(error_message);
		return false;
	} else {
		return true;	
	}    
  });  
});