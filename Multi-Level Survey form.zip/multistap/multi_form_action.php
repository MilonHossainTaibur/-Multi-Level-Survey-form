<?php 
include_once("header.php");
?>

<div class="container">		
	<div class="row well alert alert-success">		
    <?php

		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "multistap";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		  die("Connection failed: " . $conn->connect_error);
		}
        
      if (isset($_POST['submit'])) {

			$name = $_POST['name'];
			$email = $_POST['email'];
			$profession = $_POST['profession'];
			$programming_language = $_POST['programming_language'];
			$programming_tools = $_POST['programming_tools'];
			$experience = $_POST['experience'];	

			$sql = "INSERT INTO user(name, email, profession, programming_language, programming_tools, experience) VALUES('".$name."', '" . $email . "', '". $profession."', '".$programming_language."', '".$programming_tools."', '". $experience."')";

			if ($conn->query($sql) === TRUE) {
			  echo "New record created successfully";
			} else {
			  echo "Error: " . $sql . "<br>" . $conn->error;
			}

		$conn->close();
     }

     if(isset($_POST['submit'])){
		    $to = "milondiucse@gmail.com"; // this is your Email address
		    $from = $_POST['email']; // this is the sender's Email address
		    $name = $_POST['name'];
		    $profession = $_POST['profession'];
		    $subject = "Form submission";
		    $subject2 = "Copy of your form submission";
		    $message = $name . " " . $profession . " wrote the following:" . "\n\n" . $_POST['programming_language'];
		    $message2 = "Here is a copy of your message " . $name . "\n\n" . $_POST['programming_language'];

		    $headers = "From:" . $from;
		    $headers2 = "From:" . $to;
		    mail($to,$subject,$message,$headers);
		    mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
		    echo "Mail Sent. Thank you " . $name . ", we will contact you shortly.";
		    // You can also use header('Location: thank_you.php'); to redirect to another page.
		    // You cannot use header and echo together. It's one or the other.
	  }

    ?>

	</div>

</div>	
<?php include_once("footer.php");?> 